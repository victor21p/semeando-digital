# ESTADO — onde paramos

> Fonte da verdade do progresso. O Claude lê no início da sessão e atualiza a
> cada passo concluído. Não é diário: **teto ~60 linhas** (entrega antiga sai
> daqui; o `git log` guarda).

**Projeto:** _(Etapa 1)_ · **Pasta:** _(Etapa 1)_ · **Última atualização:** —
**Salvo no GitHub?** ainda não (Etapa 2) · **No ar?** ainda não (Etapa 8)

## 🧭 Trilha

| # | Etapa | Status | Concluída em |
|---|---|---|---|
| 1 | Boas-vindas e computador pronto | ▶ agora | |
| 2 | Cofre do código (Git + GitHub) | 🔒 | |
| 3 | Requisitos | 🔒 | |
| 4 | Plano | 🔒 | |
| 5 | Fundação | 🔒 | |
| 6 | Construção | 🔒 | |
| 7 | Segurança | 🔒 | |
| 8 | Publicação e rotina | 🔒 | |

▶ agora · ✅ concluída · 🔒 bloqueada (abre quando a anterior fecha)

## ▶ PRÓXIMO PASSO

**Etapa 1, passo 1.1** — apresentar o kit ao usuário, depois perguntar o nome
dele e a ideia do projeto (roteiro: `.kit/etapas/1-ambiente.md`).

## 🟡 Em andamento (onde parei dentro do passo)

- _(vazio)_

## 🙋 Aguardando o usuário (só ele pode fazer)

- _(vazio)_

## ✅ Últimas entregas (a partir da Etapa 6; no máximo 5)

| Data | Entrega | Prova |
|---|---|---|

## 📝 Anotado para depois

- _(pedidos fora de hora ficam aqui até a Etapa 4; depois vão para "Ideias
  novas" do `ROADMAP.md`)_
